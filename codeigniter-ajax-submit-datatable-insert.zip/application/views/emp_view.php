<!DOCTYPE html>
<html>
<head>
	<title>DataTables AJAX Pagination with Search and Sort in CodeIgniter</title>

	<!-- Datatable CSS -->
	<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

	<!-- jQuery Library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Datatable JS -->
	<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>
<body>


	<!-- Table -->
	<table id='empTable' class='display dataTable table' >

	  <thead>
	    <tr>
		  <th>ID</th>
	    	
	      <th>Employee name</th>
	      <th>Email</th>
	      <th>Gender</th>
	      <th>Salary</th>
	      <th>City</th>
	    </tr>
	  </thead>

	</table>
	<a href="<?php echo site_url("employee/insert")?>" class="btn btn-primary">Add New</a>
	<!-- Script -->
	<script type="text/javascript">
	$(document).ready(function(){
	   	$('#empTable').DataTable({
	      	'processing': true,
	      	'serverSide': true,
	      	'serverMethod': 'post',
	      	'ajax': {
	          'url':'<?=base_url()?>index.php/Employee/empList'
	      	},
	      	'columns': [
	         	{ data: 'id' },
	         	{ data: 'emp_name' },
	         	{ data: 'email' },
	         	{ data: 'gender' },
	         	{ data: 'salary' },
	         	{ data: 'city' },
	      	],
			'columnDefs': [{
				'targets': 0,
				'visible': true,
				'orderable': false,
				'render': function ( data, type, row ) {
					return '<div class="checkbox check-info"><input type="checkbox" id="check_delete.'+row[0]+'" class="check_delete" name="check_delete" value="'+row[0]+'"><label for="check_delete.'+row[0]+'"></label></div>';
				},
			}],
	   	});
	});
	</script>
</body>
</html>






