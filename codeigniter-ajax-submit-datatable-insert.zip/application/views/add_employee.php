<!DOCTYPE html>
<html>
<head>
	<title>DataTables AJAX Pagination with Search and Sort in CodeIgniter</title>

	<!-- Datatable CSS -->
	<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

	<!-- jQuery Library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<!-- Datatable JS -->
	<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js">
  </script>
</head>
<style>
.error{
	color:red;
}
</style>
<body>
	<div class="row">
		<div class="col-md-4"></div>		
		<div class="col-md-4 mt-12">
			<?php if(isset($message) && $message!=null ){ ?>
			<div class="alert alert-<?php echo $type ; ?>">
				<?php echo $message ; ?>
			</div>
			<?php  } ?>
			<form method="post" id="signupForm" name="signupForm" action="" autocomplete="off" enctype="multipart/form-data">
			 <div class="form-group">
				<label for="exampleInputEmail1">Email address</label>
				<input type="email" class="form-control" id="email" name="email" placeholder="Enter mae"  required>
			  </div>
			  <div class="form-group">
				<label for="exampleInputEmail1">Image</label>
				<input type="file" class="form-control" id="image" name="image" accept="image/*" required>
			  </div>
			  <div class="form-group">
				<label for="exampleInputPassword1">Password</label>
				<input type="text" class="form-control" id="password" name="password" placeholder="Password" required>
			  </div>
			  <button type="submit" class="btn btn-primary">Submit</button>
			  </form>
		</div>
		<div class="col-md-4"></div>
		
	</div>
</body>
<script>
/*    var formData = new FormData( $("#formID")[0] );

        $.ajax({
            url : baseUrl + 'uploadImage',  // Controller URL
            type : 'POST',
            data : formData,
            async : false,
            cache : false,
            contentType : false,
            processData : false,
            success : function(data) {
                successFunction(data);
            }
        });
         submitHandler: function (form) {
             $.ajax({
                 type: "POST",
                 url: "formfiles/submit.php",
                 data: $(form).serialize(),
                 success: function () {
                     $(form).html("<div id='message'></div>");
                     $('#message').html("<h2>Your request is on the way!</h2>")
                         .append("<p>someone</p>")
                         .hide()
                         .fadeIn(1500, function () {
                         $('#message').append("<img id='checkmark' src='images/ok.png' />");
                     });
                 }
             });
             return false; // required to block normal submit since you used ajax
         }
		*/
$("#signupForm").validate({
	rules: {
		password: {
			required: true,
			minlength: 5
		},
		email: {
				required: true,
				email:true
			} 
	}
});
</script>
</html>






