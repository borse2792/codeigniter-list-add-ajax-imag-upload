<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

  public function __construct(){

    parent::__construct();
    $this->load->helper('url');

    // Load model
    $this->load->model('Employee_model');

  }

  public function index(){

    // load view
    $this->load->view('emp_view');

  }

  public function empList(){
    // POST data
    $postData = $this->input->post();

    // Get data
    $data = $this->Employee_model->getEmployees($postData);

    echo json_encode($data);
  }
	public function insert(){
		$load = array();
		
		if($this->input->post()!=null){
			//echo "<pre>"; print_r($this->input->post()); 
			$image = '';
			if(isset($_FILES['image']) && $_FILES['image']!=null){
				$config = array();
				$config ['upload_path'] = "files/images/";
				$config ['allowed_types'] = "png|gif|jpeg|jpg";
				$config ['remove_spaces'] = true;
				$config ['encrypt_name'] = true;
				
				$this->upload->initialize($config);
				
				if($this->upload->do_upload('image'))	{
					$uploaddata = $this->upload->data();
					$image= $uploaddata['file_name'];
				}else{
					$error = $this->upload->display_errors("<p>","</p>");
					$this->session->set_flashdata('message',$error);
					$this->session->set_flashdata('type',"danger");
					redirect("employee/insert");
				}
			}
			$data  = $this->input->post();
			$data ['image'] = $image;
			//echo "<pre>" ; print_r($data); die();
			$this->db->where("email",$data['email']);
			$row = $this->db->get("employee")->num_rows();
			//echo $this->db->last_query();
			//echo $row;die();
			if(!$row){
				$this->db->insert("employee",$data); 
				$this->session->set_flashdata('message',"inserted");
				$this->session->set_flashdata('type',"success");
				redirect("employee");
			}else{
				$this->session->set_flashdata('message',"Email already exist");
				$this->session->set_flashdata('type',"danger");
			}
		}
		
		if($this->session->flashdata('message')){			
			$load ['message']= $this->session->flashdata('message');
			$load ['type']= $this->session->flashdata('type');
		//	echo "<pre>"; print_r($load ); die();
		}
			
		$this->load->view("add_employee",$load);
	}
}